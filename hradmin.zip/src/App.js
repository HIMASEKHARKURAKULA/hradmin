import './App.css';
import Login from './Components/Authentication/Login';
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <Login />
  );
}

export default App;
