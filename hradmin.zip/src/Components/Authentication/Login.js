import React from "react";
import "./login.css";
import logo from "../assets/Auth/CA-Logo-PNG.png";

const LeftSection = () => {
  return (
    <div className="col-lg-6 col-md-12 col-sm-12 d-table order-sm-1 order-md-1 order-xs-1 order-lg-0 login-left">
      <div
        style={{
          display: "table-cell",
          verticalAlign: "middle",
          textAlign: "center",
        }}
      >
        <div className="left-title">Important Updates</div>
        <div className="my-topbottom">
          <div className="line"></div>
          <div className="box"></div>
        </div>

        <div className="left-box">
          <div
            className="left-box-scrollbar scroller"
            // id="id"
            // data-config='{"delay" : 2000 , "amount" : 50}'
            id="left-box"
          >
            <div className="innrer-box" style={{ position: "relative" }}>
              <h6 className="box-heading" style={{ marginTop: "7px" }}>
                New Update On 22-Jan-2021
              </h6>
              <p className="box-content">
                Lorem ipsum dolor sit amet, consectetur adipiscaaa elitre, sed
                do eiusmod tempor incididunt ut laborer et doloreq magna aliqua.
                Ut enim ad minim venirpi quis nostrudexer citation.
              </p>

              <div className="hr-color"></div>
            </div>

            <div className="innrer-box mb-color">
              <h6 className="box-heading">New Update On 22-Jan-2021</h6>
              <p className="box-content">
                Lorem ipsum dolor sit amet, consectetur adipiscaaa elitre, sed
                do eiusmod tempor incididunt ut laborer et doloreq magna aliqua.
                Ut enim ad minim venirpi quis nostrudexer citation.
              </p>
              <div className="hr-color"></div>
            </div>

            <div className="innrer-box ">
              <h6 className="box-heading">New Update On 22-Jan-2021</h6>
              <p className="box-content">
                Lorem ipsum dolor sit amet, consectetur adipiscaaa elitre, sed
                do eiusmod tempor incididunt ut laborer et doloreq magna aliqua.
                Ut enim ad minim venirpi quis nostrudexer citation.
              </p>
              <div className="hr-color"></div>
            </div>

            <div className="innrer-box mb-color">
              <h6 className="box-heading">New Update On 22-Jan-2021</h6>
              <p className="box-content">
                Lorem ipsum dolor sit amet, consectetur adipiscaaa elitre, sed
                do eiusmod tempor incididunt ut laborer et doloreq magna aliqua.
                Ut enim ad minim venirpi quis nostrudexer citation.
              </p>
              <div className="hr-color"></div>
            </div>

            <div className="innrer-box mb-color">
              <h6 className="box-heading">New Update On 22-Jan-2021</h6>
              <p className="box-content">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi
                quis officia voluptate. Dignissimos explicabo, blanditiis porro
                veritatis officia voluptatibus quos. Rerum dolorum temporibus
                enim in veritatis incidunt esse, alias quaerat?
              </p>
              <div className="hr-color"></div>
            </div>

            <div className="innrer-box">
              <h6 className="box-heading">New Update On 22-Jan-2021</h6>
              <p className="box-content">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi
                quis officia voluptate. Dignissimos explicabo, blanditiis porro
                veritatis officia voluptatibus quos. Rerum dolorum temporibus
                enim in veritatis incidunt esse, alias quaerat?
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Login = () => {
  return (
    <div>
      <div className="container-fluid">
        <div className="row">
          <LeftSection />
          <div className="col-lg-6 col-md-12 col-sm-12 display-table order-sm-0 order-md-0 order-xs-0 order-lg-1 login-right">
            <div
              style={{
                textAlign: "center",
                marginTop: "80px"
              }}
            >
              <form className="vertical-middle-lg">
                <div className="vertically-middle">
                  <div className="logo text-center my-topbottom-r ">
                    <a href="/" rel="noopener noreferrer">
                      {" "}
                      <img className="logo-img" alt="logo" src={logo} />{" "}
                    </a>
                  </div>
                  <div className="right-title">PALURI ASSOCIATES</div>

                  <div className="form-box">
                    <div className="right-inner-ttl">
                      Please Login to Continue
                    </div>
                    <input
                      className="input-form"
                      type="email"
                      name="userName"
                      placeholder="Enter Registered Email Address"
                      id="email"
                    />
                    <br />
                    <input
                      className="input-form"
                      type="password"
                      name="password"
                      placeholder="Enter Password"
                      id="password"
                    />
                    <div>
                      <button
                        type="submit"
                        className="btn btn-login btn-block login-btn"
                      >
                        LOGIN
                      </button>
                    </div>
                    <div
                      className="forgot-sec"
                      style={{ marginBottom: "0.5rem", marginTop: "1rem" }}
                    >
                      <span className="cursor" style={{ cursor: "pointer" }}>
                        Forgot Password? Click Here
                      </span>
                    </div>
                    <div>
                      <hr
                        style={{
                          color: "#abb2e0",
                          height: "1px",
                          margin: "0px",
                        }}
                      />
                    </div>
                    <div className="new-to-carbanio">
                      <div className="text-center register-link">
                        <h3 className="cursor">
                          <span>New User? Click Here</span>
                        </h3>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
